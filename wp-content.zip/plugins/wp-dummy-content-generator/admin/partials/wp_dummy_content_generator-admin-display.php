<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       http://tutsocean.com/about-me
 * @since      1.0.0
 *
 * @package    wp_dummy_content_generator
 * @subpackage wp_dummy_content_generator/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
